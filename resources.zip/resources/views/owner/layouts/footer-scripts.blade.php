<!-- Bootstrap core JavaScript -->
<script src="/js/jquery-3.3.1.min.js"></script>
<script>window.jQuery || document.write('<script src="/js/jquery-3.3.1.min.js"><\/script>')</script>
<script src="/js/bootstrap.min.js"></script>
<script src="/js/script.js"></script>
<script>
    $(document).ready(function() {
        $(".first_focus").focus();
    });
</script>